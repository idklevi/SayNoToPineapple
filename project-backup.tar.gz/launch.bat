@echo off
title FocusPulse AI Launcher
echo ============================================================
echo   Starting FocusPulse AI Local Server...
echo ============================================================
cd /d "%~dp0"
python run_server.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Python not found in PATH or error starting server.
    echo Opening index.html directly in your default browser...
    start index.html
)
pause
