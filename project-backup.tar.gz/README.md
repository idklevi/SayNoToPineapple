# FocusPulse AI 🎙️⚡
### Project PR 007 | DEFINE 4.0 Hackathon

> **Real-Time Low-Latency Audio Intelligence & Negotiation Copilot**
> Built for sales negotiations, job interviews, customer support, and team planning.

---

## 🌟 Overview

**FocusPulse AI** is a production-grade, zero-install, browser-native HUD (Heads-Up Display) designed to listen to live conversations, detect negotiation dynamics (objections vs. leverage points), scrub sensitive PII in real-time, and query serverless AI models with sub-second tactical responses.

It features **Interactive Real-World Scenarios** and **Quick Tests** that work 100% offline without needing a microphone or API key for seamless evaluation.

---

## 📁 Project Structure

```
FocusPulse-AI/
├── index.html       # Complete self-contained single-page application (HTML5 + Tailwind CSS + ES6+)
├── README.md        # Documentation, architecture specs, and user guide
├── run_server.py    # Lightweight zero-dependency HTTP server with auto-browser launch
└── launch.bat       # Double-click Windows launcher (starts localhost server)
```

---

## ⚡ Quick Start

### Method 1: Instant Local Server (Recommended)
- **Double-click** `launch.bat`, or
- Run via Terminal:
  ```powershell
  python run_server.py
  ```
This automatically serves at `http://localhost:8080/index.html` and launches your browser.

### Method 2: Direct File Open
- Open `index.html` directly in **Google Chrome** or **Microsoft Edge**.

---

## 🎭 Interactive Real-World Scenarios (Zero-Setup / Offline)

Click any scenario card on the dashboard to test instant peripheral intelligence:

1. **Sales Negotiation**: `"Your competitor offers the same features for a lower price."`
   - *Classification*: `STATUS:OBJECTION` &middot; *Nudge*: **"Differentiate value"**
2. **Job Interview**: `"You don't have much industry experience."`
   - *Classification*: `STATUS:OBJECTION` &middot; *Nudge*: **"Highlight practical projects"**
3. **Customer Support**: `"I've contacted support three times, and nobody has solved my problem."`
   - *Classification*: `STATUS:OBJECTION` &middot; *Nudge*: **"Acknowledge frustration"**
4. **Team Meeting**: `"We probably can't finish this by Friday."`
   - *Classification*: `STATUS:OBJECTION` &middot; *Nudge*: **"Identify blockers"**
5. **Business Partnership**: `"We can provide the technical team if you handle implementation."`
   - *Classification*: `STATUS:LEVERAGE` &middot; *Nudge*: **"Define responsibilities"**

---

## ⚡ Quick Tests

Includes 12 instant clickable cards covering budget objections, competitor comparisons, discount requests, buying signals, decision-makers, contract approvals, timeline delays, missing specs, customer friction, team commitments, unclear roles, and next steps.

---

## 🛠️ Architectural Layers

### 1. State Architecture (`AppState`)
- Single source of truth for listening state, active objective, in-memory API key, chosen AI model, transcript history sliding window, and monotonic request IDs (preventing stale async overwrites).

### 2. Context-Aware AI Intelligence
- Analyzes the meeting objective, latest utterance, and a short sliding window of recent conversation turns.
- Strict 3-status classification protocol: `STATUS:IDLE`, `STATUS:OBJECTION | NUDGE: [...]`, `STATUS:LEVERAGE | NUDGE: [...]`.

### 3. RAM Compliance Buffer & Privacy Shield
- Synchronous regex sanitization for credit cards (`[ENCRYPTED_CARD]`), emails (`[ENCRYPTED_EMAIL]`), and phone numbers (`[ENCRYPTED_CONTACT]`).
- Audio processing is local (Web Speech API). Raw audio is never transmitted or recorded.
- In-memory keys are cleared on page unload.

### 4. Peripheral Strategic HUD
- `hud-alert-objection` (pulsing red border) & `hud-alert-leverage` (pulsing emerald border).
- Distinct `[DEMO]` vs `[LIVE]` tagging, badge cues, and tactical rationale explanations.

---

## 🛡️ Hackathon Submission Details
- **Event**: DEFINE 4.0
- **Project ID**: PR 007
- **Submission Type**: Single-Page Self-Contained Application
